import Head from 'next/head'
import Image from 'next/image'
import Walletconnect from '@/components/Walletconnect'
// import Custom from '@/components/Custom'
export default function Home() {
  return (
    <>
      <Walletconnect />
    </>
  )
}
